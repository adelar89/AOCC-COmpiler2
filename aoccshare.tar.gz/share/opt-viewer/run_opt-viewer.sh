#!/bin/sh

BASEDIR=$(dirname "$0")

echo "Generating the Optimizer Report Output..."

if [ -f optimization_database.yaml ]; then
AOR_FIX optimization_database.yaml optimization_database_cleanedup.yaml
rm -Rf optimization_database.yaml
fi

if [ -f optimization_database.opt.ld.yaml ]; then
AOR_FIX optimization_database.opt.ld.yaml optimization_database_cleanedup.opt.ld.yaml
rm -Rf optimization_database.opt.ld.yaml
fi

if [ -f optimization_database_cleanedup.yaml ]; then
python3 $BASEDIR/opt-viewer.py --generate_report_of_type=text optimization_database_cleanedup.yaml --filter=loop-vectorize
mv $PWD/reports/Optimization_Report.txt optimization_report.aor
rm -rf optimization_database_cleanedup.yaml
fi

if [ -f optimization_database_cleanedup.opt.ld.yaml ]; then
python3 $BASEDIR/opt-viewer.py --generate_report_of_type=text optimization_database_cleanedup.opt.ld.yaml --filter=loop-vectorize
mv $PWD/reports/Optimization_Report.txt optimization_opt.ld_report.aor
rm -rf optimization_database_cleanedup.opt.ld.yaml
fi

rm -rf $PWD/reports
