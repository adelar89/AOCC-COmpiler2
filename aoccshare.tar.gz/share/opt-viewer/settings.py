# settings.py

def init():
    global generate_text_report_flag
    generate_text_report_flag = True
